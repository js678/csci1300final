//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie

#include <iostream>
#include <string>
#include <fstream>


#include "Bionis.h"
#include "Mechonis.h"
#include "Map.h"
#include "Areas.h"
#include "NPCS.h"


using namespace std;


Map enterNewArea(string name, Areas areas)          //function that defines each area within the Map. There are multiple locations, so this creates new areas if in an array
{
    Map currentLocation;
    int rowCount = 0;
    int columnCount = 0;
    ifstream inFile;
    string file;

    if (name == "Colony 9")                     //checks name of each area
    {
        currentLocation.resetMap();                     //resets map, and then opens text file to read data
        inFile.open("TXTFiles/colony9XC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))                         //parses through file line by line
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')                               //checks for edge cases of location M, N, E
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)                          //parses through line of file
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);              //sets location of Mechon at file location defined by interval variables rowCount, column Count
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);              //sets location of NPC at file location defined by interval variables rowCount, column Count
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);         //sets location of Player Spawn at file location defined by interval variables rowCount, column Count
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());         //spawns mechonis and NPC
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Tephra Cave")                                         //same as Colony 9 Comments
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/tephraCaveXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());             //one note is if an area does not have an NPC, it will not spawn one
    }
    else if (name == "Bionis Leg")                                                              //same as Colony 9 Comments
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/bionisLegXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,columnCount);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,columnCount);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Colony 6")                                                //same as Colony 9 Comments
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/colony6XC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());              //notes:: if area has no mechonis, none will spawn
    }
    else if (name == "Ether Mine")                                      //same as Colony 9 Comments
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/etherMineXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
    }
    else if (name == "Satorl Marsh")                                                        //same as Colony 9 Comments
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/satorlMarshXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Makna Forest")                                    //same as Colony 9 Comments
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/maknaForestXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
    }
    else if (name == "Frontier Village")                                        //same as Colony 9 Comments
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/frontierVillageXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Alcamoth")                                                //same as Colony 9 Comments
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/alcamothXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Prison Island")                                           //same as Colony 9 Comments, final area
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/prisonIslandXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                if(file.at(0) == 'E')
                {
                    currentLocation.setPlayerColPosition(0);
                    currentLocation.setPlayerRowPosition(columnCount);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                        if(file.at(i+1) == 'E')
                        {
                            currentLocation.setPlayerColPosition(rowCount);
                            currentLocation.setPlayerRowPosition(columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
    }
    return currentLocation;
}


//main game function that is called

int main()
{
    //intializes party choosing variables
    int partyLeader;
    string leader;

    //initializes Bionis Constructor
    Bionis hero;
    
    //Instructions for Game
    std::cout << "Welcome to the world of Xenoblade Chronicles. Xenoblade Chronicles is a role-playing game" << endl;
    std::cout << "based around the heroes of Bionis, an ancient titan in the middle of the sea. In the game," << endl;
    std::cout << "you control a character as dictated below to defeat an evil machine species, the Mechon. " << endl;
    std::cout << "First, you must pick a character to begin your game. Choose from any of the seven options." << endl;

    //Character Selection Screen
    std::cout << "1. Shulk, the Hero of Bionis. He is a Glass Cannon, with Massive Damage, but Low Defenses." << endl;
    std::cout << "2. Reyn, the Protecter of Bionis. He is a Bruiser, with High Damage and Defenses." << endl;
    std::cout << "3. Sharla, the Healer of Bionis. She is a Defender, with Medium Damage, and Medium Defenses." << endl;
    std::cout << "4. Dunban, the Speedster of Bionis. He is a Speedster, with Medium Damage and Defenses, but High Agility." << endl;
    std::cout << "5. Riki, the Noponic Tank of Bionis. He is a Tank, with Low Damage, but Massive Defenses." << endl;
    std::cout << "6. Melia, the Magician of Bionis. She is a Glass Cannon, with Massive Damage and Defenses." << endl;
    std::cout << "7. Fiora, the Fallen Hero. She is an All-Rounder, with Average of All Stats." << endl;

    do {
        //takes input from user as of what character they pick
        std::cout << "Pick a Character by typing their corresponding number." << endl;
        std::cin >> partyLeader;

        //checks for invalid character name
        if (partyLeader < 1 || partyLeader > 7)
        {
            
            std::cout << "That choice is invalid. Please pick a different option." << endl;
        }
    }
    while (partyLeader < 1 || partyLeader > 7);

    //converts int into string for leaderName
    if (partyLeader == 1)
    {
        leader = "Shulk";
    }
    else if (partyLeader == 2)
    {
        leader = "Reyn";
    }
    else if (partyLeader == 3)
    {
        leader = "Sharla";
    }
    else if (partyLeader == 4)
    {
        leader = "Dunban";
    }
    else if (partyLeader == 5)
    {
        leader = "Riki";
    }
    else if (partyLeader == 6)
    {
        leader = "Melia";
    }
    else if (partyLeader == 7)
    {
        leader = "Fiora";
    }

    std::cout << "Congratulations, you have chosen " << leader << " to control for your journey." << endl;

    //Defines Hero of the Story
    hero = Bionis(leader);

    //Initializes ifstream + other necessary trackers
    ifstream inFile;
    string file;
    int count = 0;
    string temp;
    int interval = 0;

    //Initializes Arrays
    Areas areas[10];
    NPCS npcs[10];
    Mechonis mechonis[10];
    

    //opens file to define areas
    inFile.open("TXTFiles/bionisXC.txt");
    if(inFile.is_open())
    {
        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                //splits function into three separate parts
                file = file.substr(file.find(',') + 1, file.length());
                string first = file.substr(0, file.find(','));
                areas[interval] = Areas(first);

                file = file.substr(file.find(',') + 1, file.length());              //splits function into multiple parts
                string second = file.substr(0, file.find(','));
                npcs[interval] = NPCS(second);

                file = file.substr(file.find(',') + 1, file.length());
                string third = file.substr(0, file.find(','));
                mechonis[interval] = Mechonis(third);

                //defines parameters of Mechonis constructor below using setters
                switch (interval)
                {
                    case 0:
                        mechonis[interval].setName("Metal Face");           //defines name, level, health, attack, and defense: scales with character so game is possible
                        mechonis[interval].setLevel(1);

                        mechonis[interval].setHealth(50);
                        mechonis[interval].setAttack(12);
                        mechonis[interval].setSpeed(10);
                        mechonis[interval].setDefense(5);
                        break;

                    case 1:
                        mechonis[interval].setName("Arachno Queen");
                        mechonis[interval].setLevel(2);

                        mechonis[interval].setHealth(50);
                        mechonis[interval].setAttack(30);
                        mechonis[interval].setSpeed(20);
                        mechonis[interval].setDefense(5);
                        break;

                    case 2:
                        mechonis[interval].setName("Mysterious Face");
                        mechonis[interval].setLevel(3);

                        mechonis[interval].setHealth(50);
                        mechonis[interval].setAttack(50);
                        mechonis[interval].setSpeed(1);
                        mechonis[interval].setDefense(20);
                        break;

                    case 3:
                        mechonis[interval].setName("NULL");
                        mechonis[interval].setLevel(0);

                        mechonis[interval].setHealth(50);
                        mechonis[interval].setAttack(20);
                        mechonis[interval].setSpeed(1);
                        mechonis[interval].setDefense(0);
                        break;
                        
                    case 4:
                        mechonis[interval].setName("Xord");
                        mechonis[interval].setLevel(4);

                        mechonis[interval].setHealth(50);
                        mechonis[interval].setAttack(50);
                        mechonis[interval].setSpeed(1);
                        mechonis[interval].setDefense(20);
                        break;
                        
                    case 5:
                        mechonis[interval].setName("Satorl Guardian");
                        mechonis[interval].setLevel(1);

                        mechonis[interval].setHealth(100);
                        mechonis[interval].setAttack(40);
                        mechonis[interval].setSpeed(50);
                        mechonis[interval].setDefense(20);
                        break;
                        
                    case 6:
                        mechonis[interval].setName("Ancient Telethia");
                        mechonis[interval].setLevel(1);

                        mechonis[interval].setHealth(100);
                        mechonis[interval].setAttack(40);
                        mechonis[interval].setSpeed(75);
                        mechonis[interval].setDefense(10);
                        break;
                        
                    case 7:
                        mechonis[interval].setName("NULL");
                        mechonis[interval].setLevel(1);

                        mechonis[interval].setHealth(20);
                        mechonis[interval].setAttack(10);
                        mechonis[interval].setSpeed(10);
                        mechonis[interval].setDefense(5);
                        break;
                        
                    case 8:
                        mechonis[interval].setName("NULL");
                        mechonis[interval].setLevel(1);

                        mechonis[interval].setHealth(20);
                        mechonis[interval].setAttack(10);
                        mechonis[interval].setSpeed(10);
                        mechonis[interval].setDefense(5);
                        break;
                        
                    case 9:
                        mechonis[interval].setName("Mumkhar");
                        mechonis[interval].setLevel(1);

                        mechonis[interval].setHealth(100);
                        mechonis[interval].setAttack(60);
                        mechonis[interval].setSpeed(100);
                        mechonis[interval].setDefense(25);
                        break;
                    
                    default:
                        break;
                }

                interval++;
            }
        }
    }
    inFile.close();

    
    //initializes Map Constructor
    Map map[10];

    for (int i = 0; i < 10; i++)
    {
        map[i] = enterNewArea(areas[i].getAreaName(), areas[i]);
    }

    char move;  // for storing user input

    // quit after 10 moves
    int choice = 0;
    int mapChoice = 0;
    int number = 0;
    char combatChoice = ' ';
    //Makes the Map
    std::cout << "Pick a Map:" << endl;

    std::cout << "Which map would you like to enter (recommended in order)?" << endl;              //Gives User Choice of Which Map to Enter
    std::cout << "1. Colony 9" << endl;
    std::cout << "2. Tephra Cave "<< endl;
    std::cout << "3. Bionis Leg" << endl;
    std::cout << "4. Colony 6" << endl;
    std::cout << "5. Ether Mine" << endl;
    std::cout << "6. Satorl Marsh" << endl;
    std::cout << "7. Makna Forest" << endl;
    std::cout << "8. Frontier Village" << endl;
    std::cout << "9. Alcamoth" << endl;
    std::cout << "10. Prison Island" << endl;
    std::cin >> mapChoice;

    //auto assigns map as Colony 9 with number system
    switch (mapChoice)                          //Switches based on choice to welcome user to area;
    {
    case 1:
        number = 0;
        std::cout << "Welcome to Colony 9!" << endl;
        break;
    case 2:
        number = 1;
        std::cout << "Welcome to Tephra Cave!" << endl;
        break;
    case 3:
        number = 2;
        std::cout << "Welcome to Bionis Leg!" << endl;
        break;
    case 4:
        number = 3;
        std::cout << "Welcome to Colony 6!" << endl;
        break;
    case 5:
        number = 4;
        std::cout << "Welcome to Ether Mine!" << endl;
        break;
    case 6:
        number = 5;
        std::cout << "Welcome to Satorl Marsh!" << endl;
        break;
    case 7:
        number = 6;
        std::cout << "Welcome to Makna Forest!" << endl;
        break;
    case 8:
        number = 7;
        std::cout << "Welcome to Frontier Village!" << endl;
        break;
    case 9:
        number = 8;
        std::cout << "Welcome to Alcamoth!" << endl;
        break;
    case 10:
        number = 9;
        std::cout << "Welcome to Prison Island!" << endl;
        break;
    
    default:                                                //Checks for Outliers in Values
        std::cout << "Invalid input." << endl;
        number = 0;                                         //auto-assigns Colony 9 as start if user misinputs
        break;
    }
        
    //Enters Menu on Game Playing
    do
    {
        std::cout << "What would you like to do?" << endl;
        std::cout << "1. Continue Playing" << endl;
        std::cout << "2. Pick a Map" << endl;
        std::cout << "3. Quit" << endl;
        std::cin >> choice;

        switch (choice)
        {
        case 1:
            for (int i = 0; i < 5; i++) {

                map[number].displayMap();  // pretty print map_data in terminal

                std::cout << "Valid moves are: " << endl; 
                map[number].displayMoves();  // give user a menu of valid moves to pick from
                
                std::cout << "Input a move: "; 
                std::cin >> move;
                std::cout << endl;
                map[number].executeMove(move);  // move the player on map based on user input

                if (map[number].isMechonisLocation()) {
                    cout << "You've encountered an enemy!" << endl;
                    
                    cout << "Oh no! Its " << mechonis[number].getName() << "!" << endl;        
                    cout << "Would you like to attack? (Y/N)" << endl;
                    cin >> combatChoice;                                            //prompts choice of combatting enemy or running

                    int currentHealth = hero.getHealth();                              //initializes variable to return character to original health after the battle

                    //initializes damage variables
                    int heroStrike;
                    int enemyStrike;

                    //checker for invalid input
                    int check;


                    do {
                        check = 0;
                        switch (combatChoice)
                        {
                        case 'Y':
                            while (currentHealth > 0 && mechonis[number].getHealth() > 0)
                            {
                                if (hero.getSpeed() >= mechonis[number].getSpeed() * 2 && hero.getSpeed() >= mechonis[number].getSpeed() + 25)      //if player has enough speed, enemy cannot hit them
                                {
                                    cout << "You attacked first!" << endl;
                                    heroStrike = hero.getAttack() - mechonis[number].getDefense();              //Defines hero strike as your attack - their defense    

                                    if (heroStrike > 0) 
                                    {
                                        mechonis[number].setHealth(mechonis[number].getHealth() - heroStrike);
                                        cout << "You dealt " << hero.getAttack() - mechonis[number].getDefense() << " damage!" << endl;
                                    }
                                    else if (heroStrike <= 0)
                                    {
                                        cout << "Your attack bounced right off him!" << endl;
                                    }
                                    if (mechonis[number].getHealth() <= 0)                                      //checks if enemy is defeated, then they cannot attack
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        cout << "What? Their attack missed!" << endl;                          //if player has enough speed, the enemy cannot attack them
                                    }
                                }
                                else if (mechonis[number].getSpeed() >= hero.getSpeed() * 2 && mechonis[number].getSpeed() >= hero.getSpeed() + 25)         // gatekeeps late game bosses by making them impossible to hit if their speed is high enough
                                {
                                    cout << mechonis[number].getName() << ": My strike will slay you where you stand!" << endl;
                                    enemyStrike = mechonis[number].getAttack() - hero.getDefense();     //Defines enemy strike as their attack - hero defense

                                    if (enemyStrike > 0)                                                //Checks to make sure their attacks do not heal the character
                                    {
                                        currentHealth = currentHealth - enemyStrike;
                                        cout << "The enemy dealt " << enemyStrike << " damage!" << endl;
                                    }
                                    else if (enemyStrike <= 0)
                                    {
                                        cout << "Their attack bounced right off you!" << endl;
                                    }

                                    if (currentHealth <= 0)                                                      //makes sure hero cannot attack if they are dead, breaks out
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        cout << "It's your turn to attack!" << endl;
                                        heroStrike = hero.getAttack() - mechonis[number].getDefense();              //Defines hero strike as your attack - their defense    

                                        if (heroStrike > 0) 
                                        {
                                            mechonis[number].setHealth(mechonis[number].getHealth() - heroStrike);
                                            cout << "You dealt " << hero.getAttack() - mechonis[number].getDefense() << " damage!" << endl;
                                        }
                                        else if (heroStrike <= 0)
                                        {
                                            cout << "What? You missed your attack!" << endl;                         //misses attack if character is slower than opponent, gatekeeps late game bosses
                                        }
                                    }
                                }
                                else if (hero.getSpeed() >= mechonis[number].getSpeed())                     //checks if agility is higher than opponents
                                {
                                    cout << "You attacked first!" << endl;
                                    heroStrike = hero.getAttack() - mechonis[number].getDefense();              //Defines hero strike as your attack - their defense    

                                    if (heroStrike > 0) 
                                    {
                                        mechonis[number].setHealth(mechonis[number].getHealth() - heroStrike);
                                        cout << "You dealt " << hero.getAttack() - mechonis[number].getDefense() << " damage!" << endl;
                                    }
                                    else if (heroStrike <= 0)
                                    {
                                        cout << "Your attack bounced right off him!" << endl;
                                    }
                                    if (mechonis[number].getHealth() <= 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        cout << mechonis[number].getName() << ": Fear my wrath!" << endl;
                                        enemyStrike = mechonis[number].getAttack() - hero.getDefense();     //Defines enemy strike as their attack - hero defense

                                        if (enemyStrike > 0)                                                //Checks to make sure their attacks do not heal the character
                                        {
                                            currentHealth = currentHealth - enemyStrike;
                                            cout << "The enemy dealt " << mechonis[number].getAttack() - hero.getDefense() << " damage!" << endl;
                                        }
                                        else if (enemyStrike <= 0)
                                        {
                                            cout << "Their attack bounced right off you!" << endl;
                                        }
                                    }
                                    

                                }
                                else                                                                    //if agility is lower than opponent hero attacks second
                                {
                                    cout << mechonis[number].getName() << ": My strike will slay you where you stand!" << endl;
                                    enemyStrike = mechonis[number].getAttack() - hero.getDefense();     //Defines enemy strike as their attack - hero defense

                                    if (enemyStrike > 0)                                                //Checks to make sure their attacks do not heal the character
                                    {
                                        currentHealth = currentHealth - enemyStrike;
                                    
                                        cout << "The enemy dealt " << mechonis[number].getAttack() - hero.getDefense() << " damage!" << endl;
                                    }
                                    else if (enemyStrike <= 0)
                                    {
                                        cout << "Their attack bounced right off you!" << endl;          //
                                    }

                                    if (currentHealth <= 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        cout << "It's your turn to attack!" << endl;
                                        heroStrike = hero.getAttack() - mechonis[number].getDefense();              //Defines hero strike as your attack - their defense    

                                        if (heroStrike > 0) 
                                        {
                                            mechonis[number].setHealth(mechonis[number].getHealth() - heroStrike);
                                            cout << "You dealt " << hero.getAttack() - mechonis[number].getDefense() << " damage!" << endl;
                                        }
                                        else if (heroStrike <= 0)
                                        {
                                            cout << "Your attack bounced right off him!" << endl;
                                        }
                                    }
                                }
                            }

                            if (currentHealth <= 0)
                            {
                                cout << "GAME OVER:: YOU HAVE BEEN DEFEATED IN BATTLE." << endl;        //ends game, breaks out of all loops and enters stat reveal screen
                                choice = 3;                                                         
                                i = 5;
                                break;
                            }
                            else
                            {   
                                if (number == 9)
                                {
                                    cout << "Congratulations, you have beaten Xenoblade Chronicles!" << endl;
                                    choice = 3;
                                    i = 5;
                                    break;
                                }
                                cout << "You defeated the enemy! You have leveled up and received 20 gold!" << endl;

                                //uses setters to set new gold and others
                                hero.setLevel(hero.getLevel() + 1);

                                //multiplies by 1.25 to keep character strengths and help more important aspects
                                hero.setHealth(hero.getHealth() * 1.25);
                                hero.setAttack(hero.getAttack() * 1.25);
                                hero.setSpeed(hero.getSpeed() * 1.25);
                                hero.setDefense(hero.getDefense() * 1.25);

                                hero.setGold(hero.getGold() + 20);

                                choice = 2;
                                i = 5;
                                break;
                            }
                            break;

                        case 'N':
                            std::cout << "You ran away!" << endl;
                            break;

                        case 'y':                                                           //checks for case sensitivity
                            while (hero.getHealth() > 0 && mechonis[number].getHealth() > 0)
                            {
                                if (hero.getSpeed() >= mechonis[number].getSpeed() * 2 && hero.getSpeed() >= mechonis[number].getSpeed() + 25)      //if player has enough speed, enemy cannot hit them
                                {
                                    cout << "You attacked first!" << endl;
                                    heroStrike = hero.getAttack() - mechonis[number].getDefense();              //Defines hero strike as your attack - their defense    

                                    if (heroStrike > 0) 
                                    {
                                        mechonis[number].setHealth(mechonis[number].getHealth() - heroStrike);
                                        cout << "You dealt " << hero.getAttack() - mechonis[number].getDefense() << " damage!" << endl;
                                    }
                                    else if (heroStrike <= 0)
                                    {
                                        cout << "Your attack bounced right off him!" << endl;
                                    }
                                    if (mechonis[number].getHealth() <= 0)                                      //checks if enemy is defeated, then they cannot attack
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        cout << "What? Their attack missed!" << endl;                          //if player has enough speed, the enemy cannot attack them
                                    }
                                }
                                else if (mechonis[number].getSpeed() >= hero.getSpeed() * 2 && mechonis[number].getSpeed() >= hero.getSpeed() + 25)         // gatekeeps late game bosses by making them impossible to hit if their speed is high enough
                                {
                                    cout << mechonis[number].getName() << ": My strike will slay you where you stand!" << endl;
                                    enemyStrike = mechonis[number].getAttack() - hero.getDefense();     //Defines enemy strike as their attack - hero defense

                                    if (enemyStrike > 0)                                                //Checks to make sure their attacks do not heal the character
                                    {
                                        currentHealth = currentHealth - enemyStrike;
                                        cout << "The enemy dealt " << mechonis[number].getAttack() - hero.getDefense() << " damage!" << endl;
                                    }
                                    else if (enemyStrike <= 0)
                                    {
                                        cout << "Their attack bounced right off you!" << endl;
                                    }

                                    if (currentHealth <= 0)                                                      //makes sure hero cannot attack if they are dead, breaks out
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        cout << "It's your turn to attack!" << endl;
                                        heroStrike = hero.getAttack() - mechonis[number].getDefense();              //Defines hero strike as your attack - their defense    

                                        if (heroStrike > 0) 
                                        {
                                            mechonis[number].setHealth(mechonis[number].getHealth() - heroStrike);
                                            cout << "You dealt " << hero.getAttack() - mechonis[number].getDefense() << " damage!" << endl;
                                        }
                                        else if (heroStrike <= 0)
                                        {
                                            cout << "What? You missed your attack!" << endl;                         //misses attack if character is slower than opponent, gatekeeps late game bosses
                                        }
                                    }
                                }
                                else if (hero.getSpeed() >= mechonis[number].getSpeed())                     //checks if agility is higher than opponents
                                {
                                    cout << "You attacked first!" << endl;
                                    heroStrike = hero.getAttack() - mechonis[number].getDefense();              //Defines hero strike as your attack - their defense    

                                    if (heroStrike > 0) 
                                    {
                                        mechonis[number].setHealth(mechonis[number].getHealth() - heroStrike);
                                        cout << "You dealt " << hero.getAttack() - mechonis[number].getDefense() << " damage!" << endl;
                                    }
                                    else if (heroStrike <= 0)
                                    {
                                        cout << "Your attack bounced right off him!" << endl;
                                    }
                                    if (mechonis[number].getHealth() <= 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        cout << mechonis[number].getName() << ": Fear my wrath!" << endl;
                                        enemyStrike = mechonis[number].getAttack() - hero.getDefense();     //Defines enemy strike as their attack - hero defense

                                        if (enemyStrike > 0)                                                //Checks to make sure their attacks do not heal the character
                                        {
                                            currentHealth = currentHealth - enemyStrike;
                                            cout << "The enemy dealt " << mechonis[number].getAttack() - hero.getDefense() << " damage!" << endl;
                                        }
                                        else if (enemyStrike <= 0)
                                        {
                                            cout << "Their attack bounced right off you!" << endl;
                                        }
                                    }
                                    

                                }
                                else                                                                    //if agility is lower than opponent hero attacks second
                                {
                                    cout << mechonis[number].getName() << ": My strike will slay you where you stand!" << endl;
                                    enemyStrike = mechonis[number].getAttack() - hero.getDefense();     //Defines enemy strike as their attack - hero defense

                                    if (enemyStrike > 0)                                                //Checks to make sure their attacks do not heal the character
                                    {
                                        currentHealth = currentHealth - enemyStrike;
                                        cout << "The enemy dealt " << mechonis[number].getAttack() - hero.getDefense() << " damage!" << endl;
                                    }
                                    else if (enemyStrike <= 0)
                                    {
                                        cout << "Their attack bounced right off you!" << endl;          //
                                    }

                                    if (currentHealth <= 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        cout << "It's your turn to attack!" << endl;
                                        heroStrike = hero.getAttack() - mechonis[number].getDefense();              //Defines hero strike as your attack - their defense    

                                        if (heroStrike > 0) 
                                        {
                                            mechonis[number].setHealth(mechonis[number].getHealth() - heroStrike);
                                            cout << "You dealt " << hero.getAttack() - mechonis[number].getDefense() << " damage!" << endl;
                                        }
                                        else if (heroStrike <= 0)
                                        {
                                            cout << "Your attack bounced right off him!" << endl;
                                        }
                                    }
                                }
                            }
                            if (currentHealth <= 0)
                            {
                                cout << "GAME OVER:: YOU HAVE BEEN DEFEATED IN BATTLE." << endl;        //ends game, breaks out of all loops and enters stat reveal screen
                                choice = 3;                                                         
                                i = 5;
                                break;
                            }
                            else
                            {
                                cout << currentHealth << endl;
                                cout << "You defeated the enemy! You have leveled up and received 20 gold!" << endl;

                                //uses setters to set new gold and others
                                hero.setLevel(hero.getLevel() + 1);

                                //multiplies by 1.25 to keep character strengths and help more important aspects
                                hero.setHealth(hero.getHealth() * 1.25);
                                hero.setAttack(hero.getAttack() * 1.25);
                                hero.setSpeed(hero.getSpeed() * 1.25);
                                hero.setDefense(hero.getDefense() * 1.25);

                                hero.setGold(hero.getGold() + 20);

                                choice = 2;
                                i = 5;
                                break;
                            }
                            break;

                        case 'n':
                            std::cout << "You ran away!" << endl;
                            break;
                        default:
                            std::cout << "Invalid input." << endl;
                            check = 1;
                            break;
                        }
                    } while (check == 1);
                }  

                

                if (map[number].isNPCLocation()) {
                    
                    std::cout << "You've encountered " << npcs[number].getName() << "!" << endl;

                    //character text that offers weapon class
                    
                    std::cout << "Today, I can offer you the purchase of the " << npcs[number].getItemName() << ". It costs " << npcs[number].getCost() << " gold.";
                    std::cout << "The " << npcs[number].getItemName() << " modifies attack by " << npcs[number].getAttack() << "x, it modifies defense by " << npcs[number].getDefense() << "x, and it modifies agility by " << npcs[number].getSpeed() << "x." << endl;

                    //gives choice on purchase
                    char weaponChoice;
                    int checker;
                    

                    do {
                        cout << "Would you like to purchase the " << npcs[number].getItemName() << "? (Y/N)" << endl;
                        cin >> weaponChoice;
                        //offers menu and has a checker if the user chooses an invalid number

                        checker = 0;
                        if (weaponChoice == 'Y' || weaponChoice == 'y')
                        {
                            if(hero.getGold() < npcs[number].getCost())                 //checks for attempted purchase with not enough gold
                            {
                                std::cout << "I'm sorry, you don't have enough gold for this weapon." << endl;
                                break;
                            }
                            else
                            {
                                
                                //sets weapon stats and history, stackable but limited gold
                                string weaponName = npcs[number].getItemName();
                                int weaponAttack = npcs[number].getAttack();
                                int weaponDefense = npcs[number].getDefense();
                                int weaponSpeed = npcs[number].getSpeed();
                                int weaponCost = npcs[number].getCost();

                                hero.setAttack(hero.getAttack() * weaponAttack);
                                hero.setDefense(hero.getDefense() * weaponDefense);
                                hero.setSpeed(hero.getSpeed() * weaponSpeed);
                                hero.setGold(hero.getGold() - npcs[number].getCost());
                                
                                
                                std::cout << "Congratulations, you have purchased the " << npcs[number].getItemName() << "!" << endl;
                                i=5;
                                break;
                            }
                        }
                        else if (weaponChoice == 'N' || weaponChoice == 'n')            //exits if choice is no
                        {
                            std::cout << "Alright, I'll see you around." << endl;
                            break;
                        }
                        else
                        {
                            std::cout << "Invalid input." << endl;
                            checker = 1;
                        }
                        
                    }
                    while(checker == 1);                                                //loops for invalid input

                }
            }
            if(choice != 3)                                                             //checks to make sure game is not ended
            {
                std::cout << "Your current stats as " << leader << " are:" << endl;
                std::cout << "Level: " << hero.getLevel() << endl;
                std::cout << "Health: " << hero.getHealth() << endl;
                std::cout << "Attack: " << hero.getAttack() << endl;
                std::cout << "Defense: " << hero.getDefense() << endl;
                std::cout << "Agility: " << hero.getSpeed() << endl;
                std::cout << "Gold: " << hero.getGold() << endl;
            }
            break;
        
        case 2:
            //Allows User to Change Maps from Switch Statement
            std::cout << "Which map would you like to enter?" << endl;
            std::cout << "1. Colony 9" << endl;
            std::cout << "2. Tephra Cave "<< endl;
            std::cout << "3. Bionis Leg" << endl;
            std::cout << "4. Colony 6" << endl;
            std::cout << "5. Ether Mine" << endl;
            std::cout << "6. Satorl Marsh" << endl;
            std::cout << "7. Makna Forest" << endl;
            std::cout << "8. Frontier Village" << endl;
            std::cout << "9. Alcamoth" << endl;
            std::cout << "10. Prison Island" << endl;
            std::cin >> mapChoice;

            switch (mapChoice)
            {
            case 1:
                number = 0;
                std::cout << "Welcome to Colony 9!" << endl;
                break;
            case 2:
                number = 1;
                std::cout << "Welcome to Tephra Cave!" << endl;
                break;
            case 3:
                number = 2;
                std::cout << "Welcome to Bionis Leg!" << endl;
                break;
            case 4:
                number = 3;
                std::cout << "Welcome to Colony 6!" << endl;
                break;
            case 5:
                number = 4;
                std::cout << "Welcome to Ether Mine!" << endl;
                break;
            case 6:
                number = 5;
                std::cout << "Welcome to Satorl Marsh!" << endl;
                break;
            case 7:
                number = 6;
                std::cout << "Welcome to Makna Forest!" << endl;
                break;
            case 8:
                number = 7;
                std::cout << "Welcome to Frontier Village!" << endl;
                break;
            case 9:
                number = 8;
                std::cout << "Welcome to Alcamoth!" << endl;
                break;
            case 10:
                number = 9;
                std::cout << "Welcome to Prison Island!" << endl;
                break;
            
            default:
                std::cout << "Invalid input." << endl;
                break;
            }
            break;

        case 3:
            break;
        default:
            std::cout << "Invalid input." << endl;
            return 0;
        }
    }
    while (choice != 3);

    std::cout << "You ended your game as " << leader << " with these stats:" << endl;
    std::cout << "Level: " << hero.getLevel() << endl;
    std::cout << "Health: " << hero.getHealth() << endl;
    std::cout << "Attack: " << hero.getAttack() << endl;
    std::cout << "Defense: " << hero.getDefense() << endl;
    std::cout << "Agility: " << hero.getSpeed() << endl;

    std::cout << "Thank you for playing!" << endl;

    return 0;
}