//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie



#ifndef MECHONIS_H
#define MECHONIS_H

#include <iostream>
#include <string>

using namespace std;


class Mechonis                                      //Bosses of Story
{
    public:
        //constructors
        Mechonis();
        Mechonis(string nam){
            if(nam == "Metal Face")
            {
                setLevel(1);                                                  // Level of Characters, used to change all other stats

                setHealth(20);                                                 // Health of Characters
                attack = 5;                                                 // Attack of Characters
                speed = 5;                                                  // Speed of Characters
                defense = 10;                                                // Defense of Characters

                bossName = "Metal Face";                                              //Name of Boss
            }
            else if (nam == "Arachno Queen")
            {
                level = 2;

                health = 30;
                attack = 20;
                speed = 5;
                defense = 5;

                bossName = "";
            }
            else if (nam == "Mysterious Face")
            {
                level = 3;

                health = 10;
                attack = 5;
                speed = 5;
                defense = 40;

                bossName = "";
            }
            else if (nam == "Xord")
            {
                level = 4;

                health = 20;
                attack = 5;
                speed = 5;
                defense = 40;

                bossName = "";
            }
            else if (nam == "Satorl Guardian")
            {
                level = 5;

                health = 30;
                attack = 10;
                speed = 20;
                defense = 40;

                bossName = "";
            }
            else if (nam == "Ancient Telethia")
            {
                level = 6;

                health = 40;
                attack = 15;
                speed = 15;
                defense = 40;

                bossName = "";
            }
            else if (nam == "Mumkhar")
            {
                level = 7;

                health = 40;
                attack = 30;
                speed = 10;
                defense = 20;

                bossName = "";
            }
            else                                    //default class, in case is called with random name
            {
                level = 1;

                health = 0;
                attack = 0;
                speed = 0;
                defense = 0;

                bossName = nam;
            }
        };



        //setters
        void setLevel(int lev);
        void setHealth(int heal);
        void setAttack(int att);
        void setSpeed(int spe);
        void setDefense(int def);
        void setName(string nam);
        

        //getters
        int getLevel();
        int getHealth();
        int getAttack();
        int getSpeed();
        int getDefense();
        string getName();

    private:
        int level;                                                  // Level of Characters, used to change all other stats

        int health;                                                 // Health of Characters
        int attack;                                                 // Attack of Characters
        int speed;                                                  // Speed of Characters
        int defense;                                                // Defense of Characters

        // static const double blockRate = 0.1;                            // Base Block Rate (Chance to take zero damage)

        string bossName;                                            // Name of Boss
};


#endif