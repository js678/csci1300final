//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie



#ifndef NPCS_H
#define NPCS_H

#include <iostream>
#include <string>

using namespace std;


class NPCS                              //Defines Shopkeepers and other Minor Characters
{
    public:

        //constructors
        NPCS();
        NPCS(string name){
            if(name == "Dickson")
            {
                npcName = name;
                itemName = "Harbinger of Chaos";
                attackStats = 1;
                speedStats = 1;
                defenseStats = 2;
                cost = 20;
            }
            else if (name == "Juju")
            {
                npcName = name;
                itemName = "Agate";
                attackStats = 1;
                speedStats = 2;
                defenseStats = 1;
                cost = 20;
            }
            else if (name == "Otharon")
            {
                npcName = name;
                itemName = "Black Sniper";
                attackStats = 2;
                speedStats = 1;
                defenseStats = 1;
                cost = 20;
            }
            else if (name == "Wayward Nopon")
            {
                npcName = name;
                itemName = "Python";
                attackStats = 1;
                speedStats = 3;
                defenseStats = 1;
                cost = 50;
            }
            else if (name == "Chief Dunga")
            {
                npcName = name;
                itemName = "Biter";
                attackStats = 2;
                speedStats = 1;
                defenseStats = 2;
                cost = 50;
            }
            else if (name == "Kallian Antiqua")
            {
                npcName = name;
                itemName = "Imperial Staff";
                attackStats = 3;
                speedStats = 1;
                defenseStats = 1;
                cost = 50;
            }
            
        };

        //setters
        void setName(string name);
        void setItem(string item);
        void setCost(int cos);

        void setAttack(int att);
        void setSpeed(int spe);
        void setDefense(int def);

        //getters

        string getName();
        string getItemName();
        int getCost();

        int getAttack();
        int getDefense();
        int getSpeed();

    private:
        string npcName;                                 //Name of NPC


        string itemName;                                //Name of Item
        int cost;                                       //Cost of Item

        //Stats of Items (Changes Based on NPC)
        int attackStats;                                
        int speedStats;
        int defenseStats;

};


#endif