//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie


#include "NPCS.h"

#include <iostream>
#include <string>

using namespace std;


//constructors
        
NPCS::NPCS()
{
    npcName= "";
    itemName = "";
}

//setters

void NPCS::setName(string name)
{
    npcName = name;
}

void NPCS::setItem(string item)
{
    itemName = item;
}

void NPCS::setCost(int cos)
{
    cost = cos;
}

//declares stat bonuses of weapons above
void NPCS::setAttack(int att)
{
    attackStats = att;
}

void NPCS::setSpeed(int spe)
{
    speedStats = spe;
}

void NPCS::setDefense(int def)
{
    defenseStats = def;
}

//getters

string NPCS::getName()
{
    return npcName;
}

string NPCS::getItemName()
{
    return itemName;
}

int NPCS::getCost()
{
    return cost;
}

//returns stat bonuses for weapon
int NPCS::getAttack()
{
    return attackStats;
}

int NPCS::getDefense()
{
    return defenseStats;
}

int NPCS::getSpeed()
{
    return speedStats;
}