//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie


#include "Areas.h"

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

//constructors
Areas::Areas()
{
    areaName = "";
    locationXAxis = 0;
    locationYAxis = 0;
    rowCountM = 0;
    colCountM = 0;
    rowCountN = 0;
    colCountN = 0;
}



//setters
void Areas::setArea(string name)
{
    areaName = name;
}

void Areas::setLocationM(int rowCountMEC, int colCountMEC)
{
    rowCountM = rowCountMEC;
    colCountM = colCountMEC;
}
void Areas::setLocationN(int rowCountNPC, int colCountNPC)
{
    rowCountN = rowCountNPC;
    colCountN = colCountNPC;
}

//getters
int Areas::getLocationXMec()
{
    return colCountM;
}

int Areas::getLocationYMec()
{
    return rowCountM;
}

int Areas::getLocationXNPC()
{
    return colCountN;
}

int Areas::getLocationYNPC()
{
    return rowCountN;
}

string Areas::getAreaName()
{
    return areaName;
}