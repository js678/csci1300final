#ifndef MAP_H
#define MAP_H

#include <fstream>
#include <iostream>
#include <ctype.h>

using namespace std; 
 
class Map
{
     private:
          static const int num_rows = 7;
          static const int num_cols = 7;
          static const int num_npcs = 1;
          static const int num_enemies = 1;

          int playerPosition[2];
          int locationPosition[2];
          int npcPositions[num_npcs][2];
          int mechonisPositions[num_enemies][2];
          char mapData[num_rows][num_cols];

          int npc_count;
          int mechonis_count;
          bool location_on_map;

     public :
          Map();

          void resetMap();
          

          // getters
          int getPlayerRowPosition();
          int getPlayerColPosition();
          int getNPCCount();
          int getMechonisCount();

          // setters
          void setPlayerRowPosition(int);
          void setPlayerColPosition(int);
          void setNPCCount(int);
          void setMechonisCount(int);

          bool spawnNPC(int, int);
          bool spawnLocation(int, int);
          bool spawnMechonis(int, int);

          void displayMap();
          void displayMoves();  
          bool executeMove(char);

          
          bool isNPCLocation();
          bool isMechonisLocation();

          bool isLocationOnMap();
};
 
#endif