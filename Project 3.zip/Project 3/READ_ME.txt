------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ -o run Bionis.h Bionis.cpp Areas.h Areas.cpp Mechonis.h Mechonis.cpp NPCS.h NPCS.cpp Map.h Map.cpp xenobladeChroniclesDriver.cpp
Run: ./run
------------------------
DEPENDENCIES
------------------------
All classes must be in the same directory for Xenoblade Chronicles to run, same with text files
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Fall 2021 Project 3
Author: Jack Savio
Recitation: 213 - Jerome Gammie
Date: December 2, 2021
------------------------
ABOUT THIS PROJECT
------------------------
Welcome to the world of Xenoblade Chronicles. Xenoblade Chronicles is a role-playing game
based around the heroes of Bionis, an ancient titan in the middle of the sea. In the game,
you control a character as dictated below to defeat an evil machine species, the Mechon.