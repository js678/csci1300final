//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie


#include "Mechonis.h"

#include <iostream>
#include <string>

using namespace std;


//constructors
Mechonis::Mechonis()
{
    level = 1;                                                  // Level of Characters, used to change all other stats

    health = 0;                                                 // Health of Characters
    attack = 0;                                                 // Attack of Characters
    speed = 0;                                                  // Speed of Characters
    defense = 0;                                                // Defense of Characters

    bossName = "";                                              //Name of Boss
}   


//setters

void Mechonis::setLevel(int lev)
{
    level = lev;
}

void Mechonis::setHealth(int heal)
{
    health = heal;
}

void Mechonis::setSpeed(int spe)
{
    speed = spe;
}

void Mechonis::setAttack(int att)
{
    attack = att;
}

void Mechonis::setDefense(int def)
{
    defense = def;
}


void Mechonis::setName(string nam)
{
    bossName = nam;
}


//getters

int Mechonis::getLevel()
{
    return level;
}

int Mechonis::getHealth()
{
    return health;
}

int Mechonis::getAttack()
{
    return attack;
}

int Mechonis::getSpeed()
{
    return speed;
}

int Mechonis::getDefense()
{
    return defense;
}


string Mechonis::getName()
{
    return bossName;
}
