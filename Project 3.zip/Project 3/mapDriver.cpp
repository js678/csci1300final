#include "Map.h"
#include "Areas.h"


using namespace std; 

Map enterNewArea(string name, Areas areas)
{
    Map currentLocation;
    int rowCount = 0;
    int columnCount = 0;
    ifstream inFile;
    string file;

    if (name == "Colony 9")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/colony9XC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Tephra Cave")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/tephraCaveXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Bionis Leg")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/bionisLegXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Colony 6")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/colony6XC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Ether Mine")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/etherMineXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Satorl Marsh")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/satorlMarshXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Makna Forest")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/maknaForestXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Frontier Village")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/frontierVillageXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Alcamoth")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/alcamothXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    else if (name == "Prison Island")
    {
        currentLocation.resetMap();
        inFile.open("TXTFiles/prisonIslandXC.txt");

        rowCount = 0;
        columnCount = 0;

        while(getline(inFile,file))
        {
            if(file.length() > 0)
            {
                if(file.at(0) == 'M')
                {
                    areas.setLocationM(0,0);
                }
                if(file.at(0) == 'N')
                {
                    areas.setLocationN(0,0);
                }
                for (int i = 0; i <file.length(); i++)
                {    
                    if(file.at(i) == ',')
                    {
                        rowCount++;
                        if (file.at(i+1) == 'M')
                        {
                            areas.setLocationM(rowCount, columnCount);
                        }
                        if (file.at(i+1) == 'N')
                        {
                            areas.setLocationN(rowCount, columnCount);
                        }
                    }
                }
                rowCount = 0;    
            }
            columnCount++;
        }
        inFile.close();
        currentLocation.spawnMechonis(areas.getLocationXMec(),areas.getLocationYMec());
        currentLocation.spawnNPC(areas.getLocationXNPC(),areas.getLocationYNPC());
    }
    return currentLocation;
}




int main() 
{
    
    Areas area;

    Map map = enterNewArea("Tephra Cave", area);

    char move;  // for storing user input

    // quit after 10 moves
    for(int i = 0; i < 10; i++) {
        map.displayMap();  // pretty print map_data in terminal

        std::cout << "Valid moves are: " << endl; 
        map.displayMoves();  // give user a menu of valid moves to pick from
        
        std::cout << "Input a move: "; 
        cin >> move;
        std::cout << endl;
        map.executeMove(move);  // move the player on map based on user input

        if (map.isMechonisLocation()) {
            std::cout << "You've encountered an enemy!" << endl;
        }

        if (map.isNPCLocation()) {
            std::cout << "You've encountered an NPC!" << endl;
        }
    }
}
