//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie



#ifndef AREAS_H
#define AREAS_H

#include <iostream>
#include <string>
#include <fstream>


using namespace std;


class Areas                             //Makes all locations necessary for game to run
{
    public:
        //constructors
        Areas();
        
        Areas(string name){
            areaName = name;
            locationXAxis = 0;
            locationYAxis = 0;
            rowCountM = 0;
            colCountM = 0;
            rowCountN = 0;
            colCountN = 0;
        };

        Areas(string name, int locationY, int locationX){
            areaName = name;
            locationXAxis = 0;
            locationYAxis = 0;
            rowCountM = 0;
            colCountM = 0;
            rowCountN = 0;
            colCountN = 0;
        };

        //setters
        void setArea(string name);
        void setLocationM(int rowCountMEC, int colCountMEC);
        void setLocationN(int rowCountNPC, int colCountNPC);

        //getters
        int getLocationXMec();
        int getLocationYMec();
        int getLocationXNPC();
        int getLocationYNPC();
        string getAreaName();
        

    private:
        string areaName;                //There are many areas in Xenoblade Chronicles, defines area, affects NPCS and Mechonis

        int locationYAxis;              //Locations to put into Map Class
        int locationXAxis;

        int rowCount;                   //Counting Variables to define where the NPCS/Mechonis are on map
        int columnCount;
        int rowCountM;
        int colCountM;
        int rowCountN;
        int colCountN;
};


#endif 