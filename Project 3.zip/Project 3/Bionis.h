//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie



#ifndef BIONIS_H
#define BIONIS_H

#include <iostream>
#include <string>

using namespace std;


class Bionis                                                    // Main Characters Class
{
    public:
        //constructors
        Bionis()
        {
            level = 1;
            health = 0;
            speed = 0;
            defense = 0;
            attack = 0;
            gold = 0;

            heroName = "";
            weaponName = "";
        };

        Bionis(string name)
        {
            if (name == "Shulk")                    //Glass Cannon with High Speed
            {
                level = 1;
                health = 20;
                speed = 15;
                defense = 7;
                attack = 20;
                gold = 0;

                heroName = "Shulk";
                weaponName = "";
            }
            else if(name == "Reyn")                 //Bruiser with High Defenses and Low Speed
            {
                level = 1;
                health = 20;
                speed = 10;
                defense = 15;
                attack = 15;
                gold = 0;

                heroName = "Reyn";
                weaponName = "";
            }
            else if(name == "Sharla")               //Strong Damage, All-Rounder
            {
                level = 1;
                health = 20;
                speed = 10;
                defense = 7;
                attack = 25;
                gold = 0;

                heroName = "Sharla";
                weaponName = "";
            }
            else if(name == "Dunban")               //High Speed, High Attack, Mediocre Defense
            {
                level = 1;
                health = 20;
                speed = 25;
                defense = 8;
                attack = 20;
                gold = 0;

                heroName = "Dunban";
                weaponName = "";
            }
            else if(name == "Riki")                 //High Health, Low Everything Else
            {
                level = 1;
                health = 40;
                speed = 10;
                defense = 8;
                attack = 15;
                gold = 0;

                heroName = "Riki";
                weaponName = "";
            }
            else if(name == "Melia")                //True Glass Cannon, Needs Defenders
            {
                level = 1;
                health = 15;
                speed = 20;
                defense = 7;
                attack = 50;
                gold = 0;

                heroName = "Melia";
                weaponName = "";
            }
            else if(name == "Fiora")                //True All-Rounder, Equal Stats
            {
                level = 1;
                health = 15;
                speed = 15;
                defense = 15;
                attack = 15;
                gold = 0;

                heroName = "Fiora";
                weaponName = "";
            }
            else
            {
                level = 1;
                health = 0;
                speed = 0;
                defense = 0;
                attack = 0;
                gold = 0;

                heroName = "";
                weaponName = "";
            }
        };

        //setters
        void setLevel(int lev);
        
        void setHealth(int heal);
        void setAttack(int att);
        void setSpeed(int spe);
        void setDefense(int def);

        void setGold(int gol);
        void setName(string nam);
        void setWeaponName(string nameOfWeapon);
        


        //getters
        int getLevel();
        int getHealth();
        int getAttack();
        int getSpeed();
        int getDefense();
        int getGold();
        string getName();
        string getWeaponName();

    private:
        int level;                                                  // Level of Characters, used to change all other stats

        int health;                                                 // Health of Characters
        int attack;                                                 // Attack of Characters
        int speed;                                                  // Speed of Characters
        int defense;                                                // Defense of Characters

        int gold;                                                   // Used to Purchase Items that Boost Stats

        int itemCount = 1;                                          //Declares Maximum Item Count

        string heroName;                                            //Each Character(Shulk, Reyn, Sharla, Dunban, Melia, Riki, Fiora) come with different stats and bonuses
        string weaponName;                                          //string heroName would define and set all stats
};


#endif