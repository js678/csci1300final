//Jack Savio
//CSCI 1300 --- 200
//Jerome Gammie


#include "Bionis.h"

#include <iostream>
#include <string>

using namespace std;



//setters

void Bionis::setLevel(int lev)
{
    level = lev;
}

void Bionis::setHealth(int heal)
{
    health = heal;
}

void Bionis::setSpeed(int spe)
{
    speed = spe;
}

void Bionis::setAttack(int att)
{
    attack = att;
}

void Bionis::setDefense(int def)
{
    defense = def;
}

void Bionis::setGold(int gol)
{
    gold = gol;
}

void Bionis::setName(string nam)
{
    heroName = nam;
}

void Bionis::setWeaponName(string nameOfWeapon)
{
    weaponName = nameOfWeapon;
}



//getters

int Bionis::getLevel()
{
    return level;
}

int Bionis::getHealth()
{
    return health;
}

int Bionis::getAttack()
{
    return attack;
}

int Bionis::getSpeed()
{
    return speed;
}

int Bionis::getDefense()
{
    return defense;
}

int Bionis::getGold()
{
    return gold;
}

string Bionis::getName()
{
    return heroName;
}

string Bionis::getWeaponName()
{
    return weaponName;
}


